<?php
  session_start();
  if(!isset($_SESSION['userid'])){
    header("location:login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Smart Health Prediction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="/smart_health/css/style.css" rel="stylesheet"/>
</head>
<body>
  <?php include '../includes/header.php'; ?>

<div class="container mt-5">
  <h3 class="mb-4">View Diseases</h3>
  <?php
    $conn = mysqli_connect("localhost", "root", "", "smart_health");
    $qry = "select * from diseases";
    $result = mysqli_query($conn, $qry);
    if(mysqli_num_rows($result) > 0){
      echo "<table class='table table-hover table-bordered'>";
      echo "<tr class='table-dark'>";
      echo "<th>Disease ID</th>";
      echo "<th>Disease Name</th>";
      echo "<th>Description</th>";
      echo "<th>Action</th>";
      echo "</tr>";
      while($row = mysqli_fetch_array($result)){
        echo "<tr>";
        echo "<td>$row[0]</td>";
        echo "<td>$row[1]</td>";
        echo "<td>$row[2]</td>";
        echo "<td></td>";
        echo "</td>";
      }
      echo "</table>";
    }
    else{
      echo "<h2 class='text-warning'>No Record Found !!!!</h2>";
    }
    mysqli_close($conn);
  ?>
  

  <a href="../admin/dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
</div>

<?php include '../includes/footer.php'; ?>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>