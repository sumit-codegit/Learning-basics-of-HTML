<?php 
  session_start();
  if(!isset($_SESSION['userid'])){
    header("location:login.php");
  }
  $msg = "";
  include '../config/db.php';
  if(isset($_POST['add_symptom'])){
    $sname = $_POST['symptom'];
    $conn = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DBNAME);
    $qry = "insert into symptoms(symptom_name) values('$sname')";
    mysqli_query($conn, $qry);
    if(mysqli_affected_rows($conn)>0)
      $msg = "<b class='text-success'>Symptom Added Successfully !!!!<br>";
    else
      $msg = "<b class='text-danger'>Error in adding the symptom !!!!<br>";
    mysqli_close($conn);
  }
  if(isset($_GET['sid'])){
    $id = $_GET['sid'];
    $conn = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DBNAME);
    $qry = "select  * from symptoms where symptom_id = $id";
    $result = mysqli_query($conn, $qry);
    $row = mysqli_fetch_array($result);
  }
  if(isset($_POST['update_symptom'])){
      $id = $_POST['id'];
      $name = $_POST['symptom'];
      $conn = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DBNAME);
      $qry = "update symptoms set symptom_name='$name' where symptom_id=$id";
      mysqli_query($conn, $qry);
      header("location:view_symptoms.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Smart Health Prediction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="/smart_health/css/style.css" rel="stylesheet"/>
</head>
<body>
  <?php include '../includes/header.php'; ?>
<div class="container mt-5" style="min-height: 550px;">
  <?php
    if(isset($_GET['sid']))
      echo "<h3>Edit Symptom</h3>";
    else
      echo "<h3>Add Symptom</h3>";
  ?>
  

  <form method="post">
    <?php
    if(isset($_GET['sid']))
      echo "<input type='hidden' name='id' value='$row[0]' />";
    ?>
    <input type="text" value="<?php
      if(isset($_GET['sid']))
        echo $row[1];
     ?>" name="symptom" class="form-control mb-3" placeholder="Symptom Name" required>
    <button type="submit" name="<?php
      if(isset($_GET['sid']))
        echo "update_symptom";
      else
        echo "add_symptom";
     ?>" class="btn btn-primary"><?php
      if(isset($_GET['sid']))
        echo "Update Symptom";
      else
        echo "Add Symptom";
    ?></button>
    <a class="btn btn-warning" href="../admin/dashboard.php">Goto Dashboard</a>
  </form>
  <?php echo $msg; ?>
</div>

<?php include '../includes/footer.php'; ?>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>