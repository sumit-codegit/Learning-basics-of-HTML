<?php
  session_start();
  if(!isset($_SESSION['userid'])){
    header("location:login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Smart Health Prediction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="/smart_health/css/style.css" rel="stylesheet"/>
</head>
<body>
  <?php include '../includes/header.php'; ?>
<div class="container mt-5" style="min-height: 550px;">
  <h3 class="mb-4 text-center">Admin Dashboard</h3>

  <div class="row g-4">

    <!-- Manage Symptoms -->
    <div class="col-md-4">
      <div class="card text-center shadow">
        <div class="card-body">
          <h5 class="card-title">Manage Symptoms</h5>
          <p class="card-text">Add, View, Edit, Delete Symptoms</p>
          <a href="add_symptom.php" class="btn btn-primary btn-sm">Add</a>
          <a href="view_symptoms.php" class="btn btn-outline-primary btn-sm">View</a>
        </div>
      </div>
    </div>

    <!-- Manage Diseases -->
    <div class="col-md-4">
      <div class="card text-center shadow">
        <div class="card-body">
          <h5 class="card-title">Manage Diseases</h5>
          <p class="card-text">Add, View, Edit, Delete Diseases</p>
          <a href="add_disease.php" class="btn btn-success btn-sm">Add</a>
          <a href="view_diseases.php" class="btn btn-outline-success btn-sm">View</a>
        </div>
      </div>
    </div>

    <!-- Manage Doctors -->
    <div class="col-md-4">
      <div class="card text-center shadow">
        <div class="card-body">
          <h5 class="card-title">Manage Doctors</h5>
          <p class="card-text">Add, View, Edit, Delete Doctors</p>
          <a href="add_doctor.php" class="btn btn-warning btn-sm">Add</a>
          <a href="view_doctors.php" class="btn btn-outline-warning btn-sm">View</a>
        </div>
      </div>
    </div>

    <!-- Disease-Symptom Mapping -->
    <div class="col-md-6">
      <div class="card text-center shadow">
        <div class="card-body">
          <h5 class="card-title">Disease–Symptom Mapping</h5>
          <p class="card-text">Map symptoms with diseases</p>
          <a href="map_disease_symptom.php" class="btn btn-info btn-sm">Map</a>
          <a href="view_mapping.php" class="btn btn-outline-info btn-sm">View Mapping</a>
        </div>
      </div>
    </div>


  </div>

  <!-- Logout -->
  <!-- <div class="text-center mt-4">
    <a href="logout.php" class="btn btn-danger">Logout</a>
  </div> -->
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Dashboard</title>
</head>
<body>
  <h1>Welcome to Smart Health</h1>

  <!-- Logout form -->
  <form action="logout.php" method="post">
    <button type="submit">Logout</button>
  </form>
</body>
</html>
</div>

<?php include '../includes/footer.php'; ?>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>