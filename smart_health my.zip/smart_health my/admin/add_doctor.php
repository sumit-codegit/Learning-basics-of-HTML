<?php 
  session_start();
  if(!isset($_SESSION['userid'])){
    header("location:login.php");
  }
  $msg = "";
  if(isset($_POST['add_doctor'])){
    $dname = $_POST['name'];
    $spec = $_POST['specialization'];
    $contact = $_POST['contact'];
    $conn = mysqli_connect("localhost", "root", "", "smart_health");
    $qry = "insert into doctors(name, specialization, contact) values('$dname', '$spec', '$contact')";
    mysqli_query($conn, $qry);
    if(mysqli_affected_rows($conn)>0)
      $msg = "<b class='text-success'>Doctor Added Successfully !!!!<br>";
    else
      $msg = "<b class='text-danger'>Error in adding the doctor !!!!<br>";
    mysqli_close($conn);
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Smart Health Prediction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="/smart_health/css/style.css" rel="stylesheet"/>
</head>
<body>
  <?php include '../includes/header.php'; ?>
<div class="container mt-5" style="min-height: 550px;">
  <h3>Add Doctor</h3>

  <form method="post">
    <input type="text" name="name" class="form-control mb-3" placeholder="Doctor Name" required>
    <input type="text" name="specialization" class="form-control mb-3" placeholder="Specialization" required>
    <input type="text" name="contact" class="form-control mb-3" placeholder="Contact Number" required>
    <button type="submit" name="add_doctor" class="btn btn-warning">Add Doctor</button>
    <a class="btn btn-warning" href="../admin/dashboard.php">Back to Dashboard</a>
  </form>
  <?php echo $msg; ?>
</div>

<?php include '../includes/footer.php'; ?>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>