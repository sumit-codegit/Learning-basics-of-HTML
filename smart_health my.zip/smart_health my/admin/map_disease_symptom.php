<?php
  session_start();
  if(!isset($_SESSION['userid'])){
    header("location:login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Smart Health Prediction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="/smart_health/css/style.css" rel="stylesheet"/>
</head>
<body>
  <?php include '../includes/header.php'; ?>

<div class="container mt-5">
<h3>Disease – Symptom Mapping</h3>
<form method="post">
  <label><b>Disease</b></label>
  <select name="disease" class="form-control mb-3">
    <option> ---------- </option>
    <?php
      $conn = mysqli_connect("localhost", "root", "", "smart_health");
      $qry = "select * from diseases";
      $result = mysqli_query($conn, $qry);
      while($row = mysqli_fetch_assoc($result)){
        echo "<option value='$row[disease_id]'>$row[disease_name]</option>";
      }
      mysqli_close($conn);
    ?>
  </select>
  <label><b>Symptoms</b></label>
  <?php
    $conn = mysqli_connect("localhost", "root", "", "smart_health");
    $qry = "select * from symptoms";
    $result = mysqli_query($conn, $qry);
   // echo "<table class='table'>";
    $i = 0;
    while($row = mysqli_fetch_assoc($result)){
      if($i == 0)
        echo "<div class='row mb-2'>";
      echo "<div class='col-sm-2'>";
      echo "<div class='form-check'>";
      echo "<input type='checkbox' name='symptoms[]' value='$row[symptom_id]'  class='form-check-input' /> ";
      echo "<label class='form-check-label'>$row[symptom_name]</label>";
      echo "</div>";
      echo "</div>";
      $i++;
      if($i == 6){
        echo "</div>";
        $i = 0;
      }
    }
   // echo "</table>";
    mysqli_close($conn);
  ?>
  
  <button type="submit" class="btn btn-success mt-3" name="btn_map">Map</button>
  <a class="btn btn-warning" href="../admin/dashboard.php">Goto Dashboard</a>
  <?php
    if(isset($_POST['btn_map'])){
      $did = $_POST['disease'];
      $symptoms = $_POST['symptoms'];
      $conn = mysqli_connect("localhost", "root", "", "smart_health");
      foreach($symptoms as $sid){
        $qry = "insert into disease_symptom (disease_id, symptom_id) values($did, $sid)";
        mysqli_query($conn, $qry);
      }
      if(mysqli_affected_rows($conn)>0)
        echo "<b class='text-success'>Mapping Saved !!!!</b>";
      else
        echo "<b class='text-danger'>Error In Mapping !!!!</b>";
      mysqli_close($conn);
    }
  ?>
</form>

</div>

<?php include '../includes/footer.php'; ?>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>