<?php
  session_start();
  if(!isset($_SESSION['userid'])){
    header("location:login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Smart Health Prediction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="/smart_health/css/style.css" rel="stylesheet"/>
</head>
<body>
  <?php include '../includes/header.php'; ?>

<div class="container mt-5">
<h3>Disease – Symptom Mapping List</h3>

<table class="table table-bordered">
<tr>
  <th>Disease</th>
  <th>Symptom</th>
</tr>

<?php
$query = "
SELECT d.disease_name, s.symptom_name
FROM disease_symptom ds
JOIN diseases d ON ds.disease_id = d.disease_id
JOIN symptoms s ON ds.symptom_id = s.symptom_id
";

$result = mysqli_query($conn, $query);
while ($row = mysqli_fetch_assoc($result)) {
?>
<tr>
  <td><?php echo $row['disease_name']; ?></td>
  <td><?php echo $row['symptom_name']; ?></td>
</tr>
<?php } ?>
</table>

<a href="dashboard.php" class="btn btn-secondary">Back</a>
</div>

<?php include '../includes/footer.php'; ?>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>