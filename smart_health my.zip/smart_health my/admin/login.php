<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Smart Health Prediction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="/smart_health/css/style.css" rel="stylesheet"/>
</head>
<body>
  <?php include '../includes/header.php'; ?>
<div class="container mt-5" style="min-height: 550px;">
  <div class="card mx-auto" style="max-width:400px;">
    <div class="card-body">
      <h4 class="text-center">Admin Login</h4>

      <form method="post">
        <input type="text" name="username" class="form-control mb-3" placeholder="Username" required>
        <input type="password" name="password" class="form-control mb-3" placeholder="Password" required>
        <button type="submit" name="btn_login" class="btn btn-success w-100">Login</button>
      </form>
      <?php 
        if(isset($_POST['btn_login'])){
          $username = $_POST['username'];
          $password = $_POST['password'];
          include '../config/db.php';
          $conn = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DBNAME);
          $qry = "select * from admin where username = '$username' and password='$password'";
          $result = mysqli_query($conn, $qry);
          if(mysqli_num_rows($result)>0){
            $row = mysqli_fetch_array($result);
            session_start();
            $_SESSION['userid'] = $row[0];
            header("location:dashboard.php");
          }
          else{
            echo "<b class='text-danger m-5'>Invalid Username & Password!!!!!</b>";
          }
          mysqli_close($conn);
        }
      ?>
      
    </div>
  </div>
</div>

<?php include '../includes/footer.php'; ?>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>