-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 22, 2026 at 09:19 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_health`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `username`, `password`) VALUES
(1001, 'admin', 'admin@893'),
(1002, 'sumit', 'sumit@893');

-- --------------------------------------------------------

--
-- Table structure for table `diseases`
--

CREATE TABLE `diseases` (
  `disease_id` int(11) NOT NULL,
  `disease_name` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `diseases`
--

INSERT INTO `diseases` (`disease_id`, `disease_name`, `description`) VALUES
(103, 'Common Cold', 'A contagious viral infection that cause fever, body pain, cough and weekness.'),
(104, 'Flu', 'A mild viral infection that affects nose and throat causing sneezing, runny nose and cough.'),
(105, 'COVID-19', 'A viral respiratory disease that may cause fever, dry cough, breathing difficulty and loss of smell.'),
(106, 'Dengue', 'A mosquito borne disease causing high fever, server joint pain and fatigue.'),
(107, 'Malaria', 'A mosquito borne viral disease caused by parasites leading to fever, chills and sweating.'),
(108, 'Typhoid', 'A bacterial infection that spreads through contaminated food or water and cause prolonged high fever.'),
(109, 'Pneumonia', 'An infection that inflames the air sacs in the lungs and may cause chest pain and breathing problems.'),
(110, 'Asthma', 'A chronic respiratory condition that causes difficulty in breathing due to airway inflammation.'),
(111, 'Bronchitis', 'Inflammation of bronchial tubes that causes cough, mucus production, and fatigue.'),
(112, 'Migraine', 'A neurological condition causing severe headache, nausea, and sensitivity to light or sound.'),
(113, 'Food Poisoning', 'An illness caused by eating contaminated food resulting in vomiting and diarrhea.'),
(114, 'Gastritis', 'Inflammation of the stomach lining causing abdominal pain and nausea.'),
(115, 'Acidity', 'A digestive problem caused by excess stomach acid leading to heartburn and discomfort.'),
(116, 'Appendicitis', 'Inflammation of the appendix causing severe abdominal pain and fever.'),
(117, 'Demo', 'Dummy desciption');

-- --------------------------------------------------------

--
-- Table structure for table `disease_symptom`
--

CREATE TABLE `disease_symptom` (
  `id` int(11) NOT NULL,
  `disease_id` int(11) DEFAULT NULL,
  `symptom_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `disease_symptom`
--

INSERT INTO `disease_symptom` (`id`, `disease_id`, `symptom_id`) VALUES
(1, 103, 201),
(2, 103, 202),
(3, 103, 203),
(4, 104, 204),
(5, 104, 205),
(6, 104, 206),
(7, 105, 204),
(8, 105, 207),
(9, 105, 208);

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `doctor_id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `specialization` varchar(50) DEFAULT NULL,
  `contact` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`doctor_id`, `name`, `specialization`, `contact`) VALUES
(301, 'Dr. Sumit Kumar', 'Dermatologist', '9846653210'),
(302, 'Dr. Navya naveli', 'General Physician', '8923456712'),
(303, 'Dr. Nitish Kumar', 'General Physician', '6223765458'),
(304, 'Dr. Alok Kumar', 'Pulmonologist', '6224765656'),
(305, 'Dr. Nityanand Nitya', 'Cardiologist', '8958612345'),
(306, 'Dr. Ishu Kumar', 'Heart Specialist', '9952023325'),
(307, 'Dr. Dhruv Rathi', 'General Physician', '9956898756'),
(308, 'Dr. Pankaj Kumar', 'General Physician', '9935649667'),
(309, 'Dr. Sidharth Sukla', 'Digestive Specialist', '89561247523'),
(310, 'Dr. Pallavi Kumari', 'Orthopedic', '6223855434'),
(311, 'Dr. Sinu Kumari', 'Orthopedic Surgeon', '5648762145'),
(312, 'Dr. Krati Saini', 'Gyneacologist', '6248573140'),
(313, 'Dr. Princy Chahal', 'Endocrinologist', '2894621366');

-- --------------------------------------------------------

--
-- Table structure for table `symptoms`
--

CREATE TABLE `symptoms` (
  `symptom_id` int(11) NOT NULL,
  `symptom_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `symptoms`
--

INSERT INTO `symptoms` (`symptom_id`, `symptom_name`) VALUES
(201, 'Cold'),
(202, 'Runny Nose'),
(203, 'Sneezing'),
(204, 'Fever'),
(205, 'Cough'),
(206, 'Body Pain'),
(207, 'Dry Cough'),
(208, 'Loss of Smell'),
(209, 'High Fever'),
(210, 'Joint Pain'),
(211, 'Fatigue'),
(212, 'Chills'),
(213, 'Weakness'),
(214, 'Headache'),
(215, 'Chest Pain'),
(216, 'Shortness of Breath'),
(217, 'Chest Tightness '),
(218, 'Nausea'),
(219, 'Sensitivity to Light'),
(220, 'Vomiting'),
(221, 'Diarrhea'),
(222, 'Abdominal Pain'),
(223, 'Heartburn');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `gender` varchar(15) DEFAULT NULL,
  `mobile_no` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `email`, `password`, `gender`, `mobile_no`) VALUES
(1, 'sumit Kumar', 'sumitkumar@gmail.com', '123123', 'Male', 6258497618),
(2, 'Narendra Modi', 'naredra@indian.gov', '123456', 'Male', 8945762849),
(3, 'Amit Shah', 'homem@gmail.com', '12345', 'Male', 8957935483);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `diseases`
--
ALTER TABLE `diseases`
  ADD PRIMARY KEY (`disease_id`);

--
-- Indexes for table `disease_symptom`
--
ALTER TABLE `disease_symptom`
  ADD PRIMARY KEY (`id`),
  ADD KEY `disease_id` (`disease_id`),
  ADD KEY `symptom_id` (`symptom_id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`doctor_id`);

--
-- Indexes for table `symptoms`
--
ALTER TABLE `symptoms`
  ADD PRIMARY KEY (`symptom_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `diseases`
--
ALTER TABLE `diseases`
  MODIFY `disease_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;

--
-- AUTO_INCREMENT for table `disease_symptom`
--
ALTER TABLE `disease_symptom`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `doctor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=314;

--
-- AUTO_INCREMENT for table `symptoms`
--
ALTER TABLE `symptoms`
  MODIFY `symptom_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=225;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `disease_symptom`
--
ALTER TABLE `disease_symptom`
  ADD CONSTRAINT `disease_symptom_ibfk_1` FOREIGN KEY (`disease_id`) REFERENCES `diseases` (`disease_id`),
  ADD CONSTRAINT `disease_symptom_ibfk_2` FOREIGN KEY (`symptom_id`) REFERENCES `symptoms` (`symptom_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
