<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Smart Health Prediction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="/smart_health/css/style.css" rel="stylesheet"/>
</head>
<body>
  <?php include '../includes/header.php'; ?>

<div class="container mt-5" style="min-height: 550px;">
  <h3>Available Doctors</h3>

  <table class="table table-bordered">
    <tr>
      <th>Name</th>
      <th>Specialization</th>
      <th>Contact</th>
    </tr>
    <tr>
      <td>Dr. Narendra Modi</td>
      <td>Heart surgeon</td>
      <td>8925475612</td>
    </tr>
    <tr>
      <td>Dr. Amit Shah</td>
      <td>Orthopaedic</td>
      <td>5867775612</td>
    </tr>
    <tr>
      <td>Dr. Ajit Doval</td>
      <td>Psychiatrist</td>
      <td>6254876369</td>
    </tr>
    <tr>
      <td>Dr. Sinu Sumit</td>
      <td>Gynaecologist</td>
      <td>6254712364</td>
    </tr>
    <tr>
      <td>Dr. Krati Saini</td>
      <td>General Physician</td>
      <td>9841763258</td>
    </tr>
  </table>
</div>

<?php include '../includes/footer.php'; ?>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
