<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Smart Health Prediction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="/smart_health/css/style.css" rel="stylesheet"/>
</head>
<body>
    <?php include './includes/header.php'; ?>

    <div class="container mt-5">
      <div class="row align-items-center">
        <div class="col-md-6">
          <h1>Smart Health Prediction System</h1>
          <p class="text-muted">
            Select symptoms and get instant health guidance.
          </p>
        
         <a href="user/register.php" class=" btn bg-blue text-light">Get Started</a>
 <style>
  .btn {
    padding: 10px 20px;
    text-decoration: none;
    border-radius: 4px;
    transition: background-color 0.3s, color 0.3s, box-shadow 0.3s;
    display: inline-block;
  }

  .bg-blue {
    background-color: #125887; /* Bootstrap blue */
  }

  .text-light {
    color: #ffffff;
  }

  /* Hover effect */
  .btn:hover {
    background-color: #125887; /* Darker blue */
    color: #f8f9fa; /* Slightly lighter text */
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3); /* Shadow on hover */
  }
</style>
</style>
        </div>
        <div class="col-md-6 text-center">
          <img src="https://cdn-icons-png.flaticon.com/512/2966/2966487.png" class="img-fluid" width="300">
        </div>
      </div>
    </div>

    <div class="container my-5">
      <h3 class="text-center">How It Works</h3>
      <div class="row text-center mt-4">
        <div class="col-md-3 card">
          <h5 class="text-primary">Step 1</h5>
          <p>Register & Login</p>
        </div>
        <div class="col-sm-1"></div>
        <div class="col-md-3 card">
          <h5 class="text-primary">Step 2</h5>
          <p>Select Symptoms</p>
        </div>
        
        <div class="col-sm-1"></div>
        <div class="col-md-3 card">
          <h5 class="text-primary">Step 3</h5>
          <p>View Result</p>
        </div>
      </div>
    </div>
    <br>
    <?php include './includes/footer.php'; ?>

<!-- Bootstrap 5 JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>