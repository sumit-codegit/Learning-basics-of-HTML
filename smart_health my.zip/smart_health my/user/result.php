<?php
  session_start();
  if(!isset($_SESSION['uid'])){
    header("location:login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Smart Health Prediction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="/smart_health/css/style.css" rel="stylesheet"/>
</head>
<body>
  <?php include '../includes/header.php'; ?>

<div class="container mt-5" style="min-height: 550px;">
  <h3>Prediction Result</h3>

  <div class="alert alert-info">
    Based on selected symptoms, you may have: <strong>
      <?php
        include '../config/db.php';
        $symptomid = $_POST['symptoms'];
        $s = implode(",", $symptomid);
        $conn = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DBNAME);
        $qry = "select d.disease_id, d.disease_name, d.description, count(ds.symptom_id) as match_count from disease_symptom ds join diseases d on ds.disease_id=d.disease_id where ds.symptom_id in ($s) group by d.disease_id order by match_count desc";
        $result = mysqli_query($conn, $qry);
        if(mysqli_num_rows($result)>0){
       while($row = mysqli_fetch_assoc($result)){
        echo "<br>".$row['disease_name']." : ".$row['description'];
       }
        }
        else{
          echo "No Match Found!!!!";
        }
      ?>
    </strong>
  </div>

  <a href="select_symptoms.php" class="btn btn-secondary">Check Again</a>
</div>

<?php include '../includes/footer.php'; ?>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>