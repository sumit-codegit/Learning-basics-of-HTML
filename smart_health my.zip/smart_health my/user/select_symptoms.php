<?php
  session_start();
  if(!isset($_SESSION['uid'])){
    header("location:login.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Smart Health Prediction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="/smart_health/css/style.css" rel="stylesheet"/>
</head>
<body>
  <?php include '../includes/header.php'; ?>

<div class="container mt-5" style="min-height: 550px;">
  <h3>Select Your Symptoms</h3>

  <form action="result.php" method="post">
    <?php
    $conn = mysqli_connect("localhost", "root", "", "smart_health");
    $qry = "select * from symptoms";
    $result = mysqli_query($conn, $qry);
    $i = 0;
    while($row = mysqli_fetch_assoc($result)){
      if($i == 0)
        echo "<div class='row mb-2'>";
      echo "<div class='col-sm-2'>";
      echo "<div class='form-check'>";
      echo "<input type='checkbox' name='symptoms[]' value='$row[symptom_id]'  class='form-check-input' /> ";
      echo "<label class='form-check-label'>$row[symptom_name]</label>";
      echo "</div>";
      echo "</div>";
      $i++;
      if($i == 6){
        echo "</div>";
        $i = 0;
      }
    }
   // echo "</table>";
    mysqli_close($conn);
    if($i<6)
    echo "</div>";
  ?>
  
    <button class="btn btn-primary mt-3">Predict Disease</button>
  </form>
</div>

<?php include '../includes/footer.php'; ?>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
