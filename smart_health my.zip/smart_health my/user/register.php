<?php
  $msg = "";
  if(isset($_POST['btn_reg'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pwd = $_POST['password'];
    $gender = $_POST['gender'];
    $no = $_POST['phone'];
    include '../config/db.php';
    $conn = mysqli_connect(HOSTNAME, USERNAME, PASSWORD, DBNAME);
    $qry = "insert into users(name, email, password, gender, mobile_no) values('$name', '$email', '$pwd', '$gender', $no)";
    mysqli_query($conn, $qry);
    if(mysqli_affected_rows($conn) > 0)
      $msg = "<b class='text-success'>Signup Successfull !!!!!</b>";
    else
      $msg = "<b class='text-danger'>Error in Signup. Try Again !!!</b>";
    mysqli_close($conn);

  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Smart Health Prediction</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="/smart_health/css/style.css" rel="stylesheet"/>
    <script>
      function validate(){
        let email = document.getElementById("t2").value;
        let obj = new XMLHttpRequest();
        obj.open("get", "validateemail.php?eid="+email, true);
        obj.send();
        obj.onreadystatechange=function(){
          if(obj.readyState==4 && obj.status==200){
              document.getElementById("l1").innerHTML = obj.responseText;
          }
        }
      }
    </script>
</head>
<body>
  <?php include '../includes/header.php'; ?>

<div class="container mt-5" style="min-height: 550px;">
  <div class="card mx-auto" style="max-width:400px;">
    <div class="card-body">
      <h4 class="text-center">User Registration</h4>
      <form method="post">
        <input type="text" name="name" class="form-control mb-3" placeholder="Full Name" required>
        <input type="email" id="t2" onchange="validate()" name="email" class="form-control mb-3" placeholder="Email" required>
        <label id="l1"></label>
        <input type="password" name="password" class="form-control mb-3" placeholder="Password" required>
        <input type="password" name="cpassword" class="form-control mb-3" placeholder="Confirm Password">
        <select name="gender" class="form-control mb-3">
          <option>Choose Gender</option>
          <option>Male</option>
          <option>Female</option>
        </select>
        <input type="number" name="phone" class="form-control mb-3" placeholder="Mobile Number" required>
        <button type="submit" name="btn_reg" class="btn btn-primary w-100">Register</button>
      </form>
      <?php echo $msg; ?>
    </div>
  </div>
</div>

<?php include '../includes/footer.php'; ?>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
