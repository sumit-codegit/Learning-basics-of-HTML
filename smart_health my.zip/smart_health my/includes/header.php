<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container">
    <a class="navbar-brand" href="/smart_health/index.php">Smart Health</a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" 
            data-bs-target="#navbarMenu" aria-controls="navbarMenu" 
            aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarMenu">
      <ul class="navbar-nav ms-auto">
        <li class="nav-item"><a class="nav-link" href="/smart_health my/index.php">Home</a></li>
        <li class="nav-item"><a class="nav-link" href="/smart_health my/user/register.php">Register</a></li>
        <li class="nav-item"><a class="nav-link" href="/smart_health my/user/login.php">Login</a></li>
        <li class="nav-item"><a class="nav-link" href="/smart_health my/doctor/view_doctors.php">Doctors</a></li>
        <li class="nav-item"><a class="nav-link" href="/smart_health my/contact.php">Contact Us</a></li>
        <li class="nav-item"><a class="nav-link" href="/smart_health my/logout.php">Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
