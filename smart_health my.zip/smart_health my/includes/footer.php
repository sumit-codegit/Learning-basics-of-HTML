<footer class="bg-dark text-white mt-5">
  <div class="container text-center py-3">
    <p class="mb-1">Smart Health Prediction System</p>
    <small>&copy; Reserved By Sumit Kumar</small>
  </div>
</footer>

